$(function(){
    $("#myDummyTable").tablesorter({widgets: ['zebra']});
});