$(function(){
	$('.refresh').click(function() {
    location.reload();
});
});